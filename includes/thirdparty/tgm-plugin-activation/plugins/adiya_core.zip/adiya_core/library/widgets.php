<?php
// Blog Posts
class foores_blog_posts extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( 
					/* Base ID */'foores_blog_posts', 
					/* Name */esc_html__('Latest Post (Foores)','foores'), 
					array( 
						'description' => esc_html__('Showcase your Blog Posts', 'foores' )
					) 
		);
	}

	function widget($args, $instance)
	{	
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		$number = $instance['number'];
		$cat = $instance['cat'];
		$order_by = $instance['order_by'];
		$order_ad = $instance['order_ad'];	
		
		echo wp_kses( $before_widget , foores_expanded_alowed_tags() );
		
		if($title):
			echo wp_kses( $before_title.$title.$after_title , foores_expanded_alowed_tags() );
		endif;	
?>

	<ul class="comments-list">
		<?php
			$args = array('post_type' => 'post', 'posts_per_page' => $number, 'orderby' => $order_by, 'order' => $order_ad );
			if( $cat ) 
				$args['tax_query'] = array( array( 'taxonomy' => 'category', 'field' => 'id', 'terms' => $cat ) );

			$new_query = new WP_Query( $args );
			if( $new_query -> have_posts() ):
				while( $new_query -> have_posts() ): 
					$new_query -> the_post();
					$post_title = get_the_title();
					$categories = get_the_category();
		?>
		<li>
			<?php if( has_post_thumbnail() ): ?>
			<div class="alignleft">
				<a href="<?php the_permalink(); ?>"><img src="<?php echo the_post_thumbnail_url('thumbnail');?>" alt="<?php the_title(); ?>"></a>
			</div>
			<?php endif; ?>
			<small><?php
					foreach((array)$categories as $cat) {
						echo '<a href="'.get_category_link($cat->cat_ID).'"> ' . $cat->cat_name . '</a>';
						break;
					}
				?> - <?php the_time('d.m.Y'); ?></small>
			<?php if( $post_title ): ?>
			<h3><a href="<?php the_permalink(); ?>" title=""><?php echo substr(strip_tags(get_the_title()) , 0 , 35); ?></a></h3>
			<?php endif; ?>
		</li>
		<?php
				endwhile;
			endif; 
			wp_reset_postdata();
		?>
	</ul>
<?php
		echo wp_kses( $after_widget , foores_expanded_alowed_tags() );
	}
 
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = $new_instance['title'];
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		$instance['order_by'] = $new_instance['order_by'];
		$instance['order_ad'] = $new_instance['order_ad'];		
		
		return $instance;
	}

	function form($instance)
	{
		$title = ( $instance ) ? $instance['title'] : esc_html__('Recent posts', 'foores');
		$number = ( $instance ) ? $instance['number'] : 3;
		$cat = ( $instance ) ? $instance['cat'] : '';
		$order_by = ( $instance ) ? $instance['order_by'] : 'none';
		$order_ad = ( $instance ) ? $instance['order_ad'] : 'DESC';
?>			
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'foores'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('No. of Posts:', 'foores'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="number" value="<?php echo esc_attr($number); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('cat')); ?>"><?php esc_html_e('Category', 'foores'); ?></label>
            <?php wp_dropdown_categories( 
										array(
											'show_option_all'	=>	esc_html__('All Categories', 'foores'), 
											'selected'			=>	$cat,
											'class'				=>	'widefat', 
											'name'				=>	$this->get_field_name('cat')
										)
				);
			?>
        </p>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('order_by'));?>"><?php esc_html_e('Order by: ', 'foores'); ?></label>
			<select class="widefat" id="<?php echo esc_attr($this->get_field_id('order_by')); ?>" name="<?php echo esc_attr($this->get_field_name('order_by')); ?>">
			  <option value="<?php echo esc_attr($order_by); ?>">--Sorting Order--</option>
			  
			  <option value="none" <?php if($order_by=='none'){ ?> selected="selected" <?php }?>><?php esc_html_e('None', 'foores') ?></option>
			  <option value="date" <?php if($order_by=='date'){ ?> selected="selected" <?php }?>><?php esc_html_e('Date', 'foores') ?></option>
              <option value="title" <?php if($order_by=='title'){ ?> selected="selected" <?php }?>><?php esc_html_e('Title', 'foores') ?></option>
			  <option value="name" <?php if($order_by=='name'){ ?> selected="selected" <?php }?>><?php esc_html_e('Name', 'foores') ?></option>
              <option value="author" <?php if($order_by=='author'){ ?> selected="selected" <?php }?>><?php esc_html_e('Author', 'foores') ?></option>
			  <option value="comment_count" <?php if($order_by=='comment_count'){ ?> selected="selected" <?php }?>><?php esc_html_e('Comment Count', 'foores') ?></option>
              <option value="random" <?php if($order_by=='random'){ ?> selected="selected" <?php }?>><?php esc_html_e('Random', 'foores') ?></option>
			</select>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('order_ad'));?>"><?php esc_html_e('Order: ', 'foores'); ?></label>
			<select class="widefat" id="<?php echo esc_attr($this->get_field_id('order_ad')); ?>" name="<?php echo esc_attr($this->get_field_name('order_ad')); ?>">
			  <option value="<?php echo esc_attr($order_ad); ?>">--Select Order--</option>
			  
			  <option value="ASC" <?php if($order_ad=='ASC'){ ?> selected="selected" <?php }?>><?php esc_html_e('Ascending', 'foores') ?></option>
			  <option value="DESC" <?php if($order_ad=='DESC'){ ?> selected="selected" <?php }?>><?php esc_html_e('Descending', 'foores') ?></option>
			</select>
        </p>       
		<?php 
	}
	
}

// Categories
class foores_categories extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( 
					/* Base ID */'foores_categories', 
					/* Name */esc_html__('Categories (Foores)','foores'), 
					array( 
						'description' => esc_html__('Show Posts Categories', 'foores' )
					) 
		);
	}

	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		
		
		echo wp_kses( $before_widget , foores_expanded_alowed_tags() );
		
		if($title):
			echo wp_kses( $before_title.$title.$after_title , foores_expanded_alowed_tags() );
		endif;
		$categories = get_categories( array( 'orderby' => 'name', 'order'   => 'ASC' ) );
?>
		<ul class="cats">
			<?php 
				foreach((array)$categories as $cat) {
					 echo '<li><a href="'.get_category_link($cat->cat_ID).'">'. $cat->cat_name . ' <span>('. $cat->category_count.')</span></a></li>';
				}
			?>
		</ul>
<?php 
		echo wp_kses( $after_widget , foores_expanded_alowed_tags());
	}
 
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = $new_instance['title'];
			
		
		return $instance;
	}

	function form($instance)
	{
		$title = ( $instance ) ? $instance['title'] : esc_html__('Categories ', 'foores');
		
?>			
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'foores'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
          
           
		<?php 
	}
	
}

// Social Links
class foores_iconic_title_text extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct(
			'foores_iconic_title_text',
			esc_html__('Iconic Title and Text (Foores)','foores'),
			array(
				'description' => esc_html__('Socialize Your Website', 'foores' )
			) 
		);
	}

	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		$icn = $instance['icn'];
		$txt = $instance['txt'];	
		
		echo wp_kses( $before_widget , foores_expanded_alowed_tags() );
?>
		<div class="footer_wp">
			<i class="<?php echo esc_attr( $icn ); ?>"></i>
			<h3><?php echo wp_kses( $title , foores_expanded_alowed_tags() ); ?></h3>
			<p><?php echo wp_kses( $txt , foores_expanded_alowed_tags() ); ?></p>
		</div>        
<?php 
		echo wp_kses( $after_widget , foores_expanded_alowed_tags() );
	}
 
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = $new_instance['title'];
		
		$instance['icn'] = $new_instance['icn'];
		$instance['txt'] = $new_instance['txt'];
			
		
		return $instance;
	}

	function form($instance)
	{
		$title = ( $instance ) ? $instance['title'] : esc_html__('Address', 'foores');
		
		$icn = ( $instance ) ? $instance['icn'] : esc_html__('icon_pin_alt', 'foores');
		$txt = ( $instance ) ? $instance['txt'] : '';
?>			
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'foores'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('icn')); ?>"><?php esc_html_e('Title Icon', 'foores'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('icn')); ?>" name="<?php echo esc_attr($this->get_field_name('icn')); ?>" type="text" value="<?php echo esc_attr($icn); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('txt')); ?>"><?php esc_html_e('Text', 'foores'); ?></label>			
			<textarea class="widefat" rows="10" cols="20" id="<?php echo $this->get_field_id('txt'); ?>" name="<?php echo $this->get_field_name('txt'); ?>"><?php echo $txt; ?></textarea>
        </p> 
		<?php 
	}
	
}

// Footer Links
class foores_footer_multiple_links extends WP_Widget
{
    public function __construct() {
        parent::__construct(
					'foores_footer_multiple_links',
          			__('Footer Links (foores)', 'foores'),
          			array('description' =>  esc_html__('Add Links', 'foores'))
        );
        $this->courses = array(
          					'Links' => 	array(
											'coursecode'   => '',
											'professor' => '',
										),
        );
        add_action( 'in_admin_footer',array( $this,'jsfooter'));
    }
	
    public function jsfooter() {
    ?>

    <script type="text/javascript">
    jQuery(document).ready(function( $ ){
        $(document ).off('click').on('click','div.open .add-row' , function() {

        var row = $(this).closest('tr').clone(true);
        row.find('input').each(function(){
            $(this).val("");
        });
        // row.insertBefore( '#repeatable-fieldset-one tbody>tr:last' );
        $(this).parents('tr').after(row);

        return false;
      });

      $( document).on('click',  'div.open .remove-row',function() {
          if ($(this).parents('tbody').find('tr').length >1) {
            $(this).parents('tr').remove(); 
        }
        return false;
      });
    });
    </script>
    <?php
    }

	// widget
	public function widget($args, $instance)
	{		
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		$text = foores_set($instance, 'repeat');
	?>

		<div class="footer-widget footer_multiple_links widget widget_link <?php echo esc_attr( $title ? '' : 'mt-42' ); ?>">
			<?php
				if($title):
					echo wp_kses( $before_title.$title.$after_title , foores_expanded_alowed_tags() );
				endif;
			?>
			<ul>
				<?php
					foreach ($this->courses as $course_key => $course_info) {
						foreach ($instance['repeat'][$course_key ]["text"] as $k=>$field) {
						?>
							<li><a href="<?php echo esc_url($instance['repeat'][$course_key ]["link"][$k]); ?>"><?php echo esc_html($field); ?></a></li>
						<?php
						}
					}
				?>
			</ul>
		</div>

	<?php
	}

	// update
	public function update($new_instance, $old_instance)
	{
		$instance = array();
		$instance['title'] = (!empty($new_instance['title'])) ? strip_tags($new_instance['title']) : '';
		$instance['repeat'] = array();
	
		if ( isset ( $new_instance['repeat'] ) )
		{
			foreach ( $new_instance['repeat'] as $k =>$value )
			{
					$instance['repeat'][$k] = $value;
			}
		}
	
		return $instance;
	}
	
	// form
	public function form($instance)
	{
		
		$title = isset($instance[ 'title' ]) ? $instance['title'] : esc_html__('Links', 'foores');
		
		$repeatable_fields= isset ( $instance['repeat'] ) ? $instance['repeat'] : array();
		 ?>
         
		<p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'foores'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        
	<?php foreach ($this->courses as $course_key => $course_info) { ?>
	<label><?php echo esc_html($course_info['coursecode']); ?></label>
	<table id="repeatable-fieldset-one" width="100%">
	<thead>
	  <tr>
		<th width="40%">Text</th>
		<th width="40%">Link</th>
		<th width="8%"></th>
		<th width="8%"></th>
	  </tr>
	</thead>
	<tbody>
	<?php
	
	if ($repeatable_fields[$course_key ]["text"] || $repeatable_fields[$course_key ]["link"]) :
	foreach ($repeatable_fields[$course_key ]["text"] as $k=>$field) {
		?>
	<tr>
	  <td><input type="text" class="widefat" name="<?php echo esc_attr($this->get_field_name( 'repeat' )); ?>[<?php echo esc_attr($course_key);?>][text][]" value="<?php echo esc_attr($field); ?>" /></td>
	
	  <td><input type="text" class="widefat" name="<?php echo esc_attr($this->get_field_name( 'repeat' )); ?>[<?php echo esc_attr($course_key);?>][link][]" value="<?php echo esc_attr($repeatable_fields[$course_key ]["link"][$k]); ?>" /></td>
	
	  <td><a class="button remove-row" href="#">Remove</a></td>
	  <td><a class="button add-row" href="#">Add</a></td>
	
	</tr>
	<?php
	} else :
	// show a blank one
	
	?>
	<tr>
	  <td><input type="text" class="widefat" name="<?php echo esc_attr($this->get_field_name( 'repeat' )); ?>[<?php echo esc_attr($course_key);?>][text][]" /></td>
	
	
	  <td><input type="text" class="widefat" name="<?php echo esc_attr($this->get_field_name( 'repeat' )); ?>[<?php echo esc_attr($course_key);?>][link][]" value="" /></td>
	
	  <td><a class="button remove-row" href="#">Remove</a></td>
	  <td><a class="button add-row" href="#">Add</a></td>
	
	</tr>
	<?php endif; ?>
	</tbody>
	</table>
	<?php } ?>
	
	
	<!-- empty hidden one for jQuery -->
	
	<?php
	
	}
}