<?php

class SH_Taxonomies {

    function __construct() {
        // Hook into the 'init' action
        add_action('init', array($this, 'taxonomies'), 0);
    }

    // Register Custom Taxonomy
    function taxonomies() {
		
		// Portfolio
		$labels		= array(
			'name'                       => _x( 'Portfolio Category', 'Portfolio Category', 'foores' ),
			'singular_name'              => _x( 'Category', 'Category', 'foores' ),
			'menu_name'                  => esc_attr__( 'Category', 'foores' ),
			'all_items'                  => esc_attr__( 'All Categories', 'foores' ),
			'parent_item'                => esc_attr__( 'Parent Category', 'foores' ),
			'parent_item_colon'          => esc_attr__( 'Parent Category:', 'foores' ),
			'new_item_name'              => esc_attr__( 'New Category Name', 'foores' ),
			'add_new_item'               => esc_attr__( 'Add New Category', 'foores' ),
			'edit_item'                  => esc_attr__( 'Edit Category', 'foores' ),
			'update_item'                => esc_attr__( 'Update Category', 'foores' ),
			'separate_items_with_commas' => esc_attr__( 'Separate Categories with commas', 'foores' ),
			'search_items'               => esc_attr__( 'Search Categories', 'foores' ),
			'add_or_remove_items'        => esc_attr__( 'Add or remove Categories', 'foores' ),
			'choose_from_most_used'      => esc_attr__( 'Choose from the most used Categories', 'foores' ),
		);
		$rewrite	= array(
			'slug'                       => 'portfolio_category',
			'with_front'                 => true,
			'hierarchical'               => true,
		);
		$args 		= array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'rewrite'                    => $rewrite,
		);
		register_taxonomy('portfolio_category', 'portfolio', $args );
		
		// Services
		$labels		= array(
			'name'                       => _x( 'Service Category', 'Service Category', 'foores' ),
			'singular_name'              => _x( 'Category', 'Category', 'foores' ),
			'menu_name'                  => esc_attr__( 'Category', 'foores' ),
			'all_items'                  => esc_attr__( 'All Categories', 'foores' ),
			'parent_item'                => esc_attr__( 'Parent Category', 'foores' ),
			'parent_item_colon'          => esc_attr__( 'Parent Category:', 'foores' ),
			'new_item_name'              => esc_attr__( 'New Category Name', 'foores' ),
			'add_new_item'               => esc_attr__( 'Add New Category', 'foores' ),
			'edit_item'                  => esc_attr__( 'Edit Category', 'foores' ),
			'update_item'                => esc_attr__( 'Update Category', 'foores' ),
			'separate_items_with_commas' => esc_attr__( 'Separate Categories with commas', 'foores' ),
			'search_items'               => esc_attr__( 'Search Categories', 'foores' ),
			'add_or_remove_items'        => esc_attr__( 'Add or remove Categories', 'foores' ),
			'choose_from_most_used'      => esc_attr__( 'Choose from the most used Categories', 'foores' ),
		);
		$rewrite	= array(
			'slug'                       => 'service_category',
			'with_front'                 => true,
			'hierarchical'               => true,
		);
		$args 		= array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'rewrite'                    => $rewrite,
		);
		register_taxonomy('service_category', 'services', $args );
		
		// Team
		$labels		= array(
			'name'                       => _x( 'Team Category', 'Team Category', 'foores' ),
			'singular_name'              => _x( 'Category', 'Category', 'foores' ),
			'menu_name'                  => esc_attr__( 'Category', 'foores' ),
			'all_items'                  => esc_attr__( 'All Categories', 'foores' ),
			'parent_item'                => esc_attr__( 'Parent Category', 'foores' ),
			'parent_item_colon'          => esc_attr__( 'Parent Category:', 'foores' ),
			'new_item_name'              => esc_attr__( 'New Category Name', 'foores' ),
			'add_new_item'               => esc_attr__( 'Add New Category', 'foores' ),
			'edit_item'                  => esc_attr__( 'Edit Category', 'foores' ),
			'update_item'                => esc_attr__( 'Update Category', 'foores' ),
			'separate_items_with_commas' => esc_attr__( 'Separate Categories with commas', 'foores' ),
			'search_items'               => esc_attr__( 'Search Categories', 'foores' ),
			'add_or_remove_items'        => esc_attr__( 'Add or remove Categories', 'foores' ),
			'choose_from_most_used'      => esc_attr__( 'Choose from the most used Categories', 'foores' ),
		);
		$rewrite	= array(
			'slug'                       => 'team_category',
			'with_front'                 => true,
			'hierarchical'               => true,
		);
		$args 		= array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'rewrite'                    => $rewrite,
		);
		register_taxonomy('team_category', 'team', $args );
		
		// Pricing Plans
		$labels		= array(
			'name'                       => _x( 'Pricing Plan Category', 'Team Category', 'foores' ),
			'singular_name'              => _x( 'Category', 'Category', 'foores' ),
			'menu_name'                  => esc_attr__( 'Category', 'foores' ),
			'all_items'                  => esc_attr__( 'All Categories', 'foores' ),
			'parent_item'                => esc_attr__( 'Parent Category', 'foores' ),
			'parent_item_colon'          => esc_attr__( 'Parent Category:', 'foores' ),
			'new_item_name'              => esc_attr__( 'New Category Name', 'foores' ),
			'add_new_item'               => esc_attr__( 'Add New Category', 'foores' ),
			'edit_item'                  => esc_attr__( 'Edit Category', 'foores' ),
			'update_item'                => esc_attr__( 'Update Category', 'foores' ),
			'separate_items_with_commas' => esc_attr__( 'Separate Categories with commas', 'foores' ),
			'search_items'               => esc_attr__( 'Search Categories', 'foores' ),
			'add_or_remove_items'        => esc_attr__( 'Add or remove Categories', 'foores' ),
			'choose_from_most_used'      => esc_attr__( 'Choose from the most used Categories', 'foores' ),
		);
		$rewrite	= array(
			'slug'                       => 'plan_category',
			'with_front'                 => true,
			'hierarchical'               => true,
		);
		$args 		= array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'rewrite'                    => $rewrite,
		);
		register_taxonomy('plan_category', 'plans', $args );
    }

}

new SH_Taxonomies();
