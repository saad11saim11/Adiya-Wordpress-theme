<?php
/*
  Plugin Name: Adiya Core
  Plugin URI: https://www.developers-hub.com/
  Description: Required plugin for the theme.
  Version: 1.0
  Author: Thematicwebs 
  Author URI: https://themeforest.net/user/developers-hub/
  License: GPLv2
 */

if ( ! defined( 'ABSPATH' ) ) exit;
define( 'PLUG_DIR', dirname(__FILE__).'/' );
define('PLUG_URL', plugin_dir_url(__FILE__));

function cs_framework_init_check() {

    if( ! class_exists( 'foores_Elementor_Addons' ) ) {

          require_once PLUG_DIR .'/elementor_widgets/index.php';
    }

}

add_action( 'plugins_loaded', 'cs_framework_init_check' );

if (!function_exists('foores_widget_call')) {
	function foores_widget_call()
	{
		register_widget("foores_categories");
		
		register_widget("foores_blog_posts");
		
		register_widget("foores_iconic_title_text");
		
		register_widget("foores_footer_multiple_links");
	}
}
if (!function_exists('foores_social_share')) {
	function foores_social_share()
	{
		?>
        <!-- AddToAny BEGIN -->
            <a class="a2a_dd share-button" href="https://www.addtoany.com/share">Share</a>
            <script>
            var a2a_config = a2a_config || {};
            a2a_config.num_services = 10;
            </script>
            <script async src="https://static.addtoany.com/menu/page.js"></script>
        <!-- AddToAny END -->
        <?php
	}
}

if (!function_exists('foores_redirect_check_url')) {
	function foores_redirect_check_url($is_tutor_login_disabled)
	{
		$auth_url = $is_tutor_login_disabled ? wp_login_url($_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']) : '';
		return $auth_url;
	}
}

if (!function_exists('map_api')) {
	function map_api()
	{
		echo("<script src='https://maps.googleapis.com/maps/api/js?key=AIzaSyDk2HrmqE4sWSei0XdKGbOMOHN3Mm2Bf-M&ver=2.1.6'></script>");
	}
}

if (!function_exists('foores_share_social')) {

    function foores_share_social() {
?>
		<!-- AddToAny BEGIN -->
		<a class="a2a_dd share-button ms-4" href="https://www.addtoany.com/share"><i class="fa fa-share me-2"></i>share</a>
		<script>
			var a2a_config = a2a_config || {};
			a2a_config.num_services = 6;
		</script>
		<script async src="https://static.addtoany.com/menu/page.js"></script>
        <!-- AddToAny END -->
<?php
    }

}

add_action('init', 'create_adiya_core');

function create_adiya_core() {
}

include_once( plugin_dir_path(__FILE__) . 'library/widgets.php' );

// SVG Support
function add_file_types_to_uploads($file_types){
$new_filetypes = array();
$new_filetypes['svg'] = 'image/svg+xml';
$file_types = array_merge($file_types, $new_filetypes );
return $file_types;
}
add_filter('upload_mimes', 'add_file_types_to_uploads');

define('ALLOW_UNFILTERED_UPLOADS', true);


add_action( 'elementor/controls/controls_registered', function(){
	require_once( plugin_dir_path(__FILE__) . 'elementor_widgets/includes/custom_controls/multiselect.php' );
	\Elementor\Plugin::instance()->controls_manager->register_control( 'multiselect', new \THEMATICWEBS\Control_Multiselect );
});