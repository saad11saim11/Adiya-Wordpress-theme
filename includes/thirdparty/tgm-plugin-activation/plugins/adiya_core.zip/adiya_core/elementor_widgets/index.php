<?php
/**
 * Plugin Name: Foores Elementor Addon
 * Plugin URI: https://www.thematicwebs.com/
 * Description: A collection of premium quality addons or widgets for use in Elementor page builder. Elementor must be installed and activated.
 * Author: Thematicwebs
 * Author URI: https://www.thematicwebs.com/
 * Version: 1.0
 * Text Domain: foores
 * Domain Path: languages
 */
   
namespace WebangonAddon; 
// Exit if accessed directly
/*use WebangonAddon\Controls\foores_Control_Checkbox;*/

if (!defined('ABSPATH'))
    exit;
 
if (!class_exists('foores_Elementor_Addons')) :

    /**
     * Main foores_Elementor_Addons Class
     *
     */
    final class foores_Elementor_Addons {

        /** Singleton *************************************************************/

        private static $instance;

        /**
         * Main foores_Elementor_Addons Instance
         *
         * Insures that only one instance of foores_Elementor_Addons exists in memory at any one
         * time. Also prevents needing to define globals all over the place.
         */
        public static function instance() {

            if (!isset(self::$instance) && !(self::$instance instanceof foores_Elementor_Addons)) {

                self::$instance = new foores_Elementor_Addons;

                self::$instance->setup_constants();

                self::$instance->includes();

                self::$instance->hooks();

            }
            return self::$instance;
        }

        /**
         * Throw error on object clone
         *
         * The whole idea of the singleton design pattern is that there is a single
         * object therefore, we don't want the object to be cloned.
         */
        public function __clone() {
            // Cloning instances of the class is forbidden
            _doing_it_wrong(__FUNCTION__, __('Cheatin&#8217; huh?', 'foores'), '1.6');
        }

        /**
         * Disable unserializing of the class
         *
         */
        public function __wakeup() {
            // Unserializing instances of the class is forbidden
            _doing_it_wrong(__FUNCTION__, __('Cheatin&#8217; huh?', 'foores'), '1.6');
        }

        /**
         * Setup plugin constants
         *
         */
        private function setup_constants() {

            // Plugin version
            if (!defined('AE_VERSION')) {
                define('AE_VERSION', '1');
            }

            // Plugin Folder Path
            if (!defined('AE_PLUGIN_DIR')) {
                define('AE_PLUGIN_DIR', plugin_dir_path(__FILE__));
            }

            // Plugin Folder URL
            if (!defined('AE_PLUGIN_URL')) {
                define('AE_PLUGIN_URL', plugin_dir_url(__FILE__));
            }

            // Plugin Folder Path
            if (!defined('AE_ADDONS_DIR')) {
                define('AE_ADDONS_DIR', plugin_dir_path(__FILE__) . 'includes/widgets/');
            }

            // Plugin Folder Path
            if (!defined('LAE_ADDONS_URL')) {
                define('LAE_ADDONS_URL', plugin_dir_url(__FILE__) . 'includes/widgets/');
            }

        }

        /**
         * Include required files
         *
         */
        private function includes() {

            require_once AE_PLUGIN_DIR . 'includes/template-lib.php';

        }

        /**
         * Load Plugin Text Domain
         *
         * Looks for the plugin translation files in certain directories and loads
         * them to allow the plugin to be localised
         */
        public function load_plugin_textdomain() {


        }

        /**
         * Setup the default hooks and actions
         */
        private function hooks() {

            add_action('plugins_loaded', array(self::$instance, 'load_plugin_textdomain'));

            add_action('elementor/widgets/widgets_registered', array(self::$instance, 'include_widgets'));

            add_action('elementor/init', array($this, 'add_elementor_category'));
                            
        }

        /**
         * Load Frontend Scripts
         *
         */
        public function register_frontend_scripts() {
        }

        public function register_frontend_styles() {
        }
        public function add_elementor_category() {
            \Elementor\Plugin::instance()->elements_manager->add_category(
                'foores-addons',
                array(
                    'title' => __('foores Addons', 'foores'),
                    'icon' => 'fa fa-plug',
                ),
                1);
        }
        
        public function include_widgets($widgets_manager) {
            $widgets[] = '';
            foreach( glob( PLUG_DIR. 'elementor_widgets/includes/widgets/*' ) as $file ) {

                $widgets[] = substr($file, strrpos($file, '/') + 1);
            }

            if (is_array($widgets)){
                $widgets = array_filter($widgets);
                foreach ($widgets as $key => $value){
                    if (!empty($value)) {
                        require_once AE_ADDONS_DIR . ''.$value.'/index.php';
                    }
                    
                }

            }
                                                                    
        }

    }

endif;

function AE() {
    return foores_Elementor_Addons::instance();
}

AE();