<section class="zoom-courses-area pd-top-135 pd-bottom-130">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-8">
				<div class="faq-inner">
					<div class="faq-accordion" id="accordionExample">
		<?php
			$count = 1;
			foreach ($settings['faqs'] as $faq){
				if( $faq['question'] && $faq['answer'] ){
		?>
					<div class="accordion-item">
						<h4 class="accordion-header" id="<?php echo esc_attr( 'heading_'.$count ); ?>">
							<button class="accordion-button <?php echo esc_attr( $count == 1 ? '' : 'collapsed' ); ?>" type="button" data-bs-toggle="collapse" data-bs-target="#<?php echo esc_attr( 'collapse_'.$count ); ?>" aria-expanded="<?php echo esc_attr( $count == 1 ? 'true' : 'false' ); ?>" aria-controls="<?php echo esc_attr( 'collapse_'.$count ); ?>"><?php echo $faq['question']; ?></button>
						</h4>
						<div id="<?php echo esc_attr( 'collapse_'.$count ); ?>" class="accordion-collapse collapse <?php echo esc_attr( $count == 1 ? 'show' : '' ); ?>" aria-labelledby="<?php echo esc_attr( 'heading_'.$count ); ?>" data-bs-parent="#faqAccordion">
							<div class="accordion-body"><?php echo $faq['answer']; ?></div>
						</div>
					</div>
		<?php
					$count++;
				}
			}
		?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>