<?php

/*Meta Fields*/
function magnews_meta_fields(){
    return array(
        'tag' => esc_html__('Tag', 'magnews') ,
        'cat' => esc_html__('Category color', 'magnews') ,
        // 'cat_bg' => esc_html__('Category background color', 'magnews') ,
        'title' => esc_html__('Post title & permalink', 'magnews') ,
        'title_nolink' => esc_html__('Post title no permalink', 'magnews') ,
        'title_single' => esc_html__('Single post title', 'magnews') ,
        'time' => esc_html__('Date', 'magnews') ,
        'share' => esc_html__('Share button', 'magnews') ,
        //'reading' => esc_html__('Reading time', 'magnews') ,
        //'thumb' => esc_html__('Thumbnail', 'magnews') ,
        //'view' => esc_html__('Post views', 'magnews') ,
        'excerpt' => esc_html__('Excerpt', 'magnews') ,
        'space' => esc_html__('Space with separator', 'magnews') ,
        'clear' => esc_html__('Clear section', 'magnews') ,
        'h5' => esc_html__('Clear with 5px height', 'magnews') ,
        'h10' => esc_html__('Clear with 10px height', 'magnews') ,
        'w10' => esc_html__('Width 10px', 'magnews') ,
        'hr' => esc_html__('Horizontal line', 'magnews') ,
        'btn' => esc_html__('Readmore Button', 'magnews') ,
        //'pmeta-btm' => esc_html__('Bottom post meta', 'magnews') ,
        'author' => esc_html__('Author', 'magnews') ,
        //'author_img' => esc_html__('Author Image', 'magnews') ,
        'comment' => esc_html__('Comment No', 'magnews') ,
    );  
}


/**
 * Display post tag,category,date,author 
 */


function ae_build_postmeta($metas = '',$excerpt_length = '',$readmore='',$firsthumb=''){


        if ( !is_array($metas) ) {
            $metas = explode(',' , $metas); 
        }

        //var_dump($excerpt_length);
        if ( is_array($metas) ) {
                 $outz='';
            foreach( $metas as $meta ) {

                    $out = '';

                    switch ( $meta ) {

                    case 'tag':
                        $out = ae_post_tag() ;
                        break;

                    case 'cat':
                        $out = ae_single_category(false);
                        break;

                    case 'cat_bg':
                        $out = ae_single_category_bg(false);
                        break;

                    case 'time':
                        $out = ae_posted_on() ;
                        break;  

                    case 'view':
                        $out = ae_post_view() ; 
                        break;  

                    case 'title':
                        $out = fashmag_post_title() ;
                        break;

                    case 'hr':
                        $out = ae_post_spacer() ;
                        break;

                    case 'clear':
                        $out = ae_clearifix() ;
                        break;

                    case 'h5':
                        $out = ae_clearifix_h5() ;
                        break;

                    case 'h10':
                        $out = ae_clearifix_h10() ;
                        break;


                    case 'btn':
                        $out = ae_readmore_btn($readmore) ;
                        break;

                    case 'thumb':
                        $out = madmag_ft_images($firsthumb) ;
                        break;

                    case 'reading':
                        $out = fashmag_reading_time() ;
                        break;  

                    case 'share':
                        $out = magnews_share_post() ;
                        break;

                    case 'space':
                        $out = fashmag_space_meta() ;
                        break;

                    case 'view':
                        $out = fashmag_post_title() ;
                        break;

                    case 'title_nolink':
                        $out = fashmag_post_title_nolink() ;
                        break;  

                    case 'author':
                        $out = fashmag_author();
                        break;

                    case 'w10':
                        $out = fashmag_width_10();
                        break;

                    case 'comment':
                        $out = fashmag_comment() ;
                        break;

                    case 'excerpt':
                        $out = fashmag_excerpt_shortcode($excerpt_length);
                        break;

                    }

                if ( !empty( $meta ) ) {
                    $outz .= $out;
                }       

                }   
            echo '<div class="meta-wrap">'.$outz.'</div>';  

            }   

}

function ae_drop_cat($tax) {

        $categories_obj = get_categories('taxonomy='.$tax.'');
        $categories = array();

        foreach ($categories_obj as $pn_cat) {
            $categories[$pn_cat->cat_ID] = $pn_cat->cat_name;
        }
        return $categories;         
}

function ae_drop_posts($post_type){
    $args = array(
      'numberposts' => -1,
      'post_type'   => $post_type
    );

    $posts = get_posts( $args );        
    $list = array();
    foreach ($posts as $cpost){
    //  print_r($cform);
        $list[$cpost->ID] = $cpost->post_title;
    }
    return $list;
}

function ae_folio_cat(){

        global $post;
        $output='';        
        $ids=  'portfolio-category';                   
        $terms = wp_get_post_terms($post->ID, $ids);        
        $separator = ', ';
        if($terms){
            foreach($terms as $term) {
                $term_link = get_term_link($term);
                $tax_id = get_term( $term->term_id, 'portfolio-category' );
                //$count = $tax_id->count;
                $output .='<a class="gallery-cat" href="' . esc_url($term_link) . '">'.$term->name.'</a>'.$separator;
            }   
            echo trim($output, $separator);
        }       
}



function misha_loadmore_ajax_handler(){
     
    $per_page = $_POST['posts'];
    $cat = explode(',' , $_POST['cat']);
    $col_num = $_POST['column'];
    $column = fw_grid_col( $col_num );

    $meta_f = $_POST['metaf'];
    $meta_r = $_POST['metar'];
    $excerptf = $_POST['excerptf'];
    $excerptr = $_POST['excerptr'];
    $thumbf = $_POST['thumbf'];
    $thumbr = $_POST['thumbr'];
    $heading = $_POST['rhead'];
    
    $template = $_POST['template'];
    $dir = $_POST['dir'];
    if ($dir=='prev'){
        $paged = $_POST['page'] - 1;
    } else {
        $paged = $_POST['page'] + 1;
    }

    //var_dump($col_num);
    $query_args = array(
        'post_type' => 'post',
        'paged' => $paged,
        'posts_per_page' => $per_page,
        'tax_query' => array(
            array(
                'taxonomy' => 'category',
                'field' => 'term_id',
                'terms' => $cat,
            ) ,
        ) ,
    );
    
    $the_query = new WP_Query( $query_args );
    require AE_PLUGIN_DIR.'includes/loops/'. $template .'.php'; 
    die(); 
}
 
 
 
add_action('wp_ajax_loadmore', 'misha_loadmore_ajax_handler'); 
add_action('wp_ajax_nopriv_loadmore', 'misha_loadmore_ajax_handler'); 


function misha_tabcat_ajax_handler(){
     
    $per_page = $_POST['posts'];
    $cat = explode(',' , $_POST['catid']);
    $metaf = $_POST['metaf'];
    $class = $_POST['column'];
    $excerptf = $_POST['excerptf'];
    $template = $_POST['template'];
    $thumb = $_POST['thumb'];
    $page = (get_query_var('paged')) ? get_query_var('paged') : 1;
    $query_args = array(
        'post_type' => 'portfolio',
        'paged' => $paged,
        'posts_per_page' => $per_page,
        'tax_query' => array(
            array(
                'taxonomy' => 'portfolio-category',
                'field' => 'term_id',
                'terms' => $cat,
            ) ,
        ) ,
    );

    $the_query = new WP_Query( $query_args );
    $max =  $the_query->max_num_pages;
    $current =  $the_query->paged;
    //var_dump($thumb);
    echo '<span class="xyz" data-max="'.$max.'" ></span>';
    //require(AE_PLUGIN_DIR.'includes/loops/tabcat.php'); 
    require AE_PLUGIN_DIR.'includes/loops/'. $template .'.php';           
    die(); 
}
 
 
 
add_action('wp_ajax_tabcat', 'misha_tabcat_ajax_handler'); 
add_action('wp_ajax_nopriv_tabcat', 'misha_tabcat_ajax_handler'); 


function madmag_bg_images($thumbnail){

    global $post;
    $post_id = $post->ID;   
    $featured_image = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID),$thumbnail);
    if ( !$featured_image) {
        return ;
    };  
    $image_url =  $featured_image[0];
    $lazy='data-bg='.$image_url.'';

    $bg_image = 'background-image:url('.$image_url.');';    
    $out = ($bg_image) ? 'style='.$bg_image.'' : '';    

    return esc_attr($out);
    
}

 
function pagination_bar( $custom_query='' ) {
    if ($custom_query){
        $q = $custom_query;
    } else {
        global $wp_query;
        $q = $wp_query;
    }
    
    $total_pages = $q->max_num_pages;
    $big = 999999999; // need an unlikely integer

    if ($total_pages > 1){
        $current_page = max(1, get_query_var('paged'));
        echo '<div class="wrap-pagi">';
        echo paginate_links(array(
            'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
            'format' => '?paged=%#%',
            'current' => $current_page,
            'total' => $total_pages,
            'type' => 'list',
            'prev_text' => '<i class="fa fa-angle-left"></i>',
            'next_text' => '<i class="fa fa-angle-right"></i>',            
        ));
        echo '</div>';
    }
}