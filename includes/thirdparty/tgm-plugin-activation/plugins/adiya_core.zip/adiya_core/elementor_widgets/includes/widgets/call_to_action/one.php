<?php
$title		= $settings['title'] ? '<h2>'.$settings['title'].'</h2>' : '';
$text		= $settings['text'] ? '<h5>'.$settings['text'].'</h5>' : '';
?>
<!-- cta Area Start-->
<div class="cta-area text-center pd-top-70 pd-bottom-80 bg-main">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-8">
				<div class="cta-wrap">
					<?php  
						echo $title.$text; 
						if($settings['b_txt']):
					?>
						<a class="btn btn-white" href="<?php echo $settings['b_lnk']; ?>"><?php echo $settings['b_txt']; ?></a>
					<?php endif;?>
				</div>
			</div>
		</div>
	</div>            
</div>
<!-- cta Area End -->