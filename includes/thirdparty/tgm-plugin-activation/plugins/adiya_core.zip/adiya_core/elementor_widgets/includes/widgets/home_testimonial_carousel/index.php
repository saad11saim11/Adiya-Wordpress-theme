<?php

namespace WebangonAddon\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
 
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly


class home_testimonial_carousel extends Widget_Base {

    public function get_name() {
        return 'home_testimonial_carousel';
    }

    public function get_title() {
        return __('Testimonials Carousel', 'foores');
    }
 
    public function get_icon() {
        return 'eicon-testimonial-carousel';
    }

    public function get_categories() {
        return ['foores-addons'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __('General', 'foores'),
            ]
        );
		
		$this->add_control(
			'be_heading', [
                'type' => Controls_Manager::TEXTAREA,
                'label' =>   esc_html__('Section Title', 'foores'),
                'label_block' => true,
            ]
		);
		
		$this->add_control(
			'col_size',
			[
				'type' => Controls_Manager::SWITCHER,
				'label' => esc_html__( '3 Column', 'foores' ),
				'label_on' => esc_html__( 'Yes', 'foores' ),
				'label_off' => esc_html__( 'No', 'foores' ),
			]
		);
		
		$repeater = new \Elementor\Repeater();


        $repeater->add_control(
            'text', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Testimonial Title', 'foores'),
                'label_block' => true,
				'default' => 'Super fast WordPress themes',
            ]
        );
		$repeater->add_control(
            'textlnk', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Testimonial Link', 'foores'),
                'label_block' => true,
            ]
        );
		
		$repeater->add_control(
            'desc', [
                'type' => Controls_Manager::TEXTAREA,
                'label' =>   esc_html__('Description', 'foores'),
                'label_block' => true,
				'default' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Velit placerat sit feugiat ornare tortor arcu, euismod pellentesque porta. Lacus, semper congue consequat, potenti suspendisse luctus cras vel.',
            ]
        );

        $repeater->add_control(
            'name', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Name', 'foores'),
                'label_block' => true,
				'default' => '- Jessica Jessy',
            ]
        );
		
		 $repeater->add_control(
            'vid_lnk', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Video Link', 'foores'),
                'label_block' => true,
            ]
        );
		
 
		
		$this->add_control(
            'testimonials',
            [
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ name }}}',                
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_section();
    }
        
    protected function render() {

        $settings = $this->get_settings();
        require dirname(__FILE__) .'/one.php';      
    }

}

$widgets_manager->register_widget_type(new \WebangonAddon\Widgets\home_testimonial_carousel());