    <!-- about Area Start-->
    <section class="about-area pd-top-150 pd-bottom-120">
        <div class="container">
            <div class="row justify-content-center">
				<?php 
				foreach ($settings['clients'] as $client){ 
					$img = wp_get_attachment_image($client['image']['id'], 'full');
			?>
                <div class="col-lg-6">
                    <div class="single-about-wrap">
                        <div class="thumb">
                            <?php echo $img;?>
                        </div>
                        <div class="wrap-details">
                            <h3><a href="<?php echo $client['textlnk'];?>"><?php echo $client['text'];?></a></h3>
                            <p><?php echo $client['desc'];?></p>
                            <a class="btn btn-base-light-border" href="<?php echo $client['btlnk'];?>"><?php echo $client['Bttext'];?></a>
                        </div>
                    </div>
                </div>
				<?php }?>
            </div>
        </div>
    </section>
    <!-- about Area End -->