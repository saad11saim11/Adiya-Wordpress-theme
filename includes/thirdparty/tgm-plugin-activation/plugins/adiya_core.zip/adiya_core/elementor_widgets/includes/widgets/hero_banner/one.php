<?php
$title		= $settings['title'] ? '<h1>'.$settings['title'].'</h1>' : '';
$text		= $settings['text'] ? '<div class="banner-content"><p>'.$settings['text'].'</p></div>' : '';
$p_txt		= $settings['p_txt'];
$form		=$settings['show_form'];
$img 		= $settings['bgimg']['url'];
?>
    <!-- Banner Area Start-->
    <section class="banner-area" style="background-image: url(<?php echo $img; ?>);">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-8 align-self-center">
                    <div class="banner-inner text-md-start text-center">
                        <?php 
							echo $title.$text;
							if($form):
						?>
							<form action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
								<div class="single-input-wrap">
									<input type="text" name="s" value="<?php echo get_search_query(); ?>" placeholder="<?php echo $p_txt?>">
									<button><i class="fa fa-search"></i></button>
								</div>
							</form>
						<?php endif;?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Banner Area End -->