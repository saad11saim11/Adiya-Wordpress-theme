<!-- client Area Start-->
<section class="client-area">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="client-slider owl-carousel">
					<?php 
						foreach ($settings['clients'] as $client){ 
							$img = wp_get_attachment_image($client['image']['id'], 'full');
					?>
					<div class="item">
						<?php echo $img;?>
					</div>
					<?php }?>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- client Area End -->