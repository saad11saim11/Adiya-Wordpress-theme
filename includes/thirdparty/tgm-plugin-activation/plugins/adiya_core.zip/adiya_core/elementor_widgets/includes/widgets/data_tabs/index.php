<?php

namespace WebangonAddon\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
 
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly


class data_tabs extends Widget_Base {

    public function get_name() {
        return 'data_tabs';
    }

    public function get_title() {
        return __('Data tabs', 'foores');
    }
 
    public function get_icon() {
        return 'eicon-form-horizontal';
    }

    public function get_categories() {
        return ['foores-addons'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __('General', 'foores'),
            ]
        );
		
		
		$this->add_control(
            'title', [
                'type' => Controls_Manager::TEXTAREA,
                'label' =>   esc_html__('Title', 'foores'),
                'label_block' => true,
				'default' => 'Discover your potential',
            ]
        );
	
		
		$repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'tab_title', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Tab Title', 'foores'),
                'label_block' => true,
				'default' => 'Plan your course',
            ]
        );
		
		 $repeater->add_control(
            'title', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Title', 'foores'),
                'label_block' => true,
				'default' => 'Record your video',
            ]
        );
		
		$repeater->add_control(
            'text', [
                'type' => Controls_Manager::TEXTAREA,
                'label' =>   esc_html__('Text', 'foores'),
                'label_block' => true,
            ]
        );
		
		$repeater->add_control(
            'image', [
                'type' => Controls_Manager::MEDIA,
                'label' =>   esc_html__('Side Image', 'foores'),
                'label_block' => true,
            ]
        );
		
		$this->add_control(
            'sections',
            [
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
        );

        $this->end_controls_tab();
		
		


        $this->end_controls_section();
    }
        
    protected function render() {

        $settings = $this->get_settings();
        require dirname(__FILE__) .'/one.php';      
    }

}

$widgets_manager->register_widget_type(new \WebangonAddon\Widgets\data_tabs());