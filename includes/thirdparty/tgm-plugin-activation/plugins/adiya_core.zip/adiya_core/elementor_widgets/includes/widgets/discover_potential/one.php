<?php
$title		= $settings['title'] ? '<h2>'.$settings['title'].'</h2>' : '';
$text		= $settings['text'] ? '<p>'.$settings['text'].'</p>' : '';
$b1_txt		= $settings['b1_txt'];
$b1_lnk		=$settings['b1_lnk'];
$b2_txt		= $settings['b2_txt'];
$b2_lnk		=$settings['b2_lnk'];
$img 		= $settings['bgimg']['url'];
?>

    <!-- potential Area Start-->
    <div class="potential-area-2 pt-4 pd-bottom-140">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 align-self-center">
                    <div class="thumb mb-lg-0 mb-4 me-xl-5 me-lg-3 me-0">
                        <img src="<?php echo $img; ?>" alt="img">
                    </div>
                </div>
                <div class="col-lg-6 align-self-center">
                    <div class="section-title mb-0">
                         <?php  echo $title.$text;?>
                        <ul class="list-inner">
							<?php foreach ($settings['points'] as $point){ ?>
                            <li><i class="fa fa-check"></i><?php echo $point['point'];?></li>
							<?php }?>
                        </ul>
                        <?php if($b1_txt): ?>
                        <a class="btn btn-base me-4" href="<?php echo $b1_lnk;?>"><?php echo $b1_txt;?></a>
						<?php
							endif;
							if( $b2_txt ):
						?>
                        <a class="btn btn-base-light-border" href="<?php echo $b2_lnk;?>"><?php echo $b2_txt;?></a>
						<?php endif; ?>
                    </div>
                </div>                
            </div>
        </div>            
    </div>
    <!-- potential Area End -->