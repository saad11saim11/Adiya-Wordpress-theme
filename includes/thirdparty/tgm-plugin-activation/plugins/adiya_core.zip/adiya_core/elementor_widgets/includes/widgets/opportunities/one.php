<?php
$title		= $settings['title'] ? '<h2>'.$settings['title'].'</h2>' : '';
$text		= $settings['text'] ? '<p>'.$settings['text'].'</p>' : '';
?>
    <!-- intro Area Start-->
    <div class="text-center pd-top-135">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="section-title">
                        <?php  echo $title.$text;?>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
				<?php 
					foreach ($settings['sections'] as $section){ 
						$img = wp_get_attachment_image($section['image']['id'], 'full');
				?>
               	 	<div class="col-lg-4 col-sm-6">
                    <div class="single-intro-wrap-2">
                        <div class="thumb">
                            <?php echo $img;?>
                        </div>
                        <div class="wrap-details">
                            <h4><a href="<?php echo $section['link'];?>"><?php echo $section['title'];?></a></h4>
                            <p><?php echo $section['text'];?></p>
                        </div>
                    </div>
                </div>
				
				<?php }?>
            </div>
        </div>            
    </div>
    <!-- intro Area End -->