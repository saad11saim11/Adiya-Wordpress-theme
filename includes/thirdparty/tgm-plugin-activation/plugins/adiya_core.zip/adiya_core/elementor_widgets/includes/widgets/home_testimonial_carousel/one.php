<!-- testimonial courses Area Start-->
<section class="testimonial-courses-area pd-bottom-150">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="section-title">
					<h2><?php echo $settings['be_heading']; ?></h2>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="<?php echo esc_attr( $settings['col_size'] ? 'testimonial-slider-2' : 'testimonial-slider' ); ?> owl-carousel">
					<?php
						foreach ($settings['testimonials'] as $testimonial){
							$name = $testimonial['name'] ? '<span> '.$testimonial['name'].'</span>' : '';
							$description = $testimonial['desc'] ? '<p>'.$testimonial['desc'].'</p>' : '';
							$vid_lnk = $testimonial['vid_lnk'] ? '<a class="play-btn" href="'.$testimonial['vid_lnk'].'"><i class="fa fa-play"></i></a>' : '';
					?>
						<div class="item">
						<div class="single-testimonial-wrap">
							<div class="thumb">
								<img src="<?php echo get_template_directory_uri('template_url').'/assets/img/quote.png'?>" alt="img">
							</div>
							<div class="wrap-details">
								<h5><a href="<?php echo $testimonial['textlnk']?>"><?php echo $testimonial['text']?></a></h5>
								<?php echo $description. $name. $vid_lnk;?>
							</div>
						</div>
					</div>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- testimonial courses Area End -->