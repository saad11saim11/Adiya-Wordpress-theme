<?php

namespace WebangonAddon\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
 
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly


class opportunities extends Widget_Base {

    public function get_name() {
        return 'opportunities';
    }

    public function get_title() {
        return __('Exceptional Opportunities', 'foores');
    }
 
    public function get_icon() {
        return 'eicon-form-horizontal';
    }

    public function get_categories() {
        return ['foores-addons'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __('General', 'foores'),
            ]
        );
		
		
		$this->add_control(
            'title', [
                'type' => Controls_Manager::TEXTAREA,
                'label' =>   esc_html__('Title', 'foores'),
                'label_block' => true,
				'default' => 'Exceptional opportunities',
            ]
        );
		
		$this->add_control(
            'text', [
                'type' => Controls_Manager::TEXTAREA,
                'label' =>   esc_html__('Text', 'foores'),
                'label_block' => true,
				'default' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Eget aenean accumsan bibendum gravida maecenas augue elementum et neque. Suspendisse imperdiet .','foores'),
            ]
        );
		
		$repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'title', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Title', 'foores'),
                'label_block' => true,
				'default' => 'Earn money',
            ]
        );
		
		$repeater->add_control(
            'link', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Link', 'foores'),
                'label_block' => true,
            ]
        );
		
		$repeater->add_control(
            'text', [
                'type' => Controls_Manager::TEXTAREA,
                'label' =>   esc_html__('Text', 'foores'),
                'label_block' => true,
				'default' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Dui praesent nam fermentum, est neque, dignissim. Phasellus feugiat elit vulputate convallis.',
            ]
        );
		
		$repeater->add_control(
            'image', [
                'type' => Controls_Manager::MEDIA,
                'label' =>   esc_html__('Image', 'foores'),
                'label_block' => true,
            ]
        );
		
		$this->add_control(
            'sections',
            [
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
        );

        $this->end_controls_tab();
		
		


        $this->end_controls_section();
    }
        
    protected function render() {

        $settings = $this->get_settings();
        require dirname(__FILE__) .'/one.php';      
    }

}

$widgets_manager->register_widget_type(new \WebangonAddon\Widgets\opportunities());