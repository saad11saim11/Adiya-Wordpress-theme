<?php
$title		= $settings['title'] ? '<h1 class="text-white">'.$settings['title'].'</h1>' : '';
$text		= $settings['text'] ? '<div class="banner-content me-0"><p class="text-white">'.$settings['text'].'</p></div>' : '';
$img 		= $settings['bgimg']['url'];
?>
    <!-- Banner Area Start-->
    <section class="banner-area instructor-banner p-0 bg-blue">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-5 col-8">
                    <div class="thumb">
                        <img src="<?php echo $img; ?>" alt="img">
                    </div>
                </div>
                <div class="col-md-7 col-sm-10 align-self-center">
                    <div class="banner-inner text-md-start text-center">
                        <?php  
							echo $title.$text; 
							if($settings['b_txt']):
						?>
                        	<a class="btn btn-base" href="<?php echo $settings['b_lnk']; ?>"><?php echo $settings['b_txt']; ?></a>
						<?php endif;?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Banner Area End -->