<?php

namespace WebangonAddon\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
 
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly


class blog_listing extends Widget_Base {

    public function get_name() {
        return 'blog_listing';
    }

    public function get_title() {
        return __('Blog Posts Listing', 'foores');
    }
 
    public function get_icon() {
        return 'eicon-posts-carousel';
    }

    public function get_categories() {
        return ['foores-addons'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __('General', 'foores'),
            ]
        );
		
		
		$this->add_control(
            'title', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Title', 'foores'),
                'label_block' => true,
				'default' => 'Development Articles',
            ]
        );
		
		$this->add_control(
            'btn_txt', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Button Text', 'foores'),
                'label_block' => true,
				'default' => 'See All',
            ]
        );
		
		$this->add_control(
            'btn_lnk', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Button Link', 'foores'),
                'label_block' => true,
            ]
        );
		
		$this->add_control(
			'number',
			[
				'type' => Controls_Manager::NUMBER,
				'label' => esc_html__( 'Number of Posts to show', 'foores' ),
				'min' => 0,
				'max' => 100,
				'step' => 1,
				'default' => 4,
			]
		);
		
		$this->add_control(
			'category',
			[
				'label' => esc_html__( 'Specific Category', 'foores' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'none',
				'options' => foores_get_categories(),
			]
		);
		
		$this->add_control(
			'order_by',
			[
				'label' => esc_html__( 'Order by', 'foores' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'none',
				'options' => [					
					'none'  => esc_html__( 'None', 'foores' ),
					'date' => esc_html__( 'Date', 'foores' ),
					'title' => esc_html__( 'Title', 'foores' ),
					'name' => esc_html__( 'Name', 'foores' ),
					'author' => esc_html__( 'Author', 'foores' ),
					'comment_count' => esc_html__( 'Comment Count', 'foores' ),
					'random' => esc_html__( 'Random', 'foores' ),
				],
			]
		);
		
		$this->add_control(
			'order',
			[
				'label' => esc_html__( 'Order', 'foores' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'none',
				'options' => [
					'ASC'  => esc_html__( 'Ascending', 'foores' ),
					'DESC' => esc_html__( 'Descending', 'foores' ),
				],
			]
		);
		
        $this->end_controls_section();
    }
        
    protected function render() {

        $settings = $this->get_settings();
        require dirname(__FILE__) .'/one.php';      
    }

}

$widgets_manager->register_widget_type(new \WebangonAddon\Widgets\blog_listing());