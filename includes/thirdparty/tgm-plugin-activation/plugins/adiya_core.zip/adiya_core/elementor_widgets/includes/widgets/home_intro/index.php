<?php

namespace WebangonAddon\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
 
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly


class home_intro extends Widget_Base {

    public function get_name() {
        return 'home_intro';
    }

    public function get_title() {
        return __('Our Intro', 'foores');
    }
 
    public function get_icon() {
        return 'eicon-accordion';
    }

    public function get_categories() {
        return ['foores-addons'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __('General', 'foores'),
            ]
        );
		
		$repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'title', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Title', 'foores'),
                'label_block' => true,
				'default' => esc_html__('130,000 online courses','foores'),
            ]
        );
		
		$repeater->add_control(
            'title_lnk', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Title Link', 'foores'),
                'label_block' => true,
				'default' => esc_html__('#','foores'),
            ]
        );

        $repeater->add_control(
            'text', [
                'type' => Controls_Manager::TEXTAREA,
                'label' =>   esc_html__('text', 'foores'),
                'label_block' => true,
				'default' => esc_html__('Enjoy a variety of fresh topics','foores'),
            ]
        );
		
		$repeater->add_control(
            'img', [
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,               
                'label' =>   esc_html__('Side Image', 'foores'),
            ]
        ); 

		
		$this->add_control(
            'intros',
            [
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ title }}}',                
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_section();
    }
        
    protected function render() {

        $settings = $this->get_settings();
        require dirname(__FILE__) .'/one.php';      
    }

}

$widgets_manager->register_widget_type(new \WebangonAddon\Widgets\home_intro());