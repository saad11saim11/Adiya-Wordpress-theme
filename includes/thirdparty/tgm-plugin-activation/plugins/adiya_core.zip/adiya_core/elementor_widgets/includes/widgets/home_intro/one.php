<!-- intro Area Start-->
    <div class="container">
        <div class="intro-area">
            <div class="row justify-content-center">
				<?php
					foreach ($settings['intros'] as $intro){
						$img = wp_get_attachment_image($intro['img']['id'], 'foores-64x65');
						$title		= $intro['title'] ;
						$lnk		= $intro['title_lnk'];
						$txt		= $intro['text'];
						
						if( $title || $lnk || $img ){
				?>
							<div class="col-lg-3 col-sm-6">
								<div class="single-intro-wrap">
									<div class="thumb">
										<?php echo $img; ?>
									</div>
									<div class="wrap-details">
										<h6><a href="<?php echo $lnk; ?>"><?php echo $title; ?></a></h6>
										<p><?php echo $txt; ?></p>
									</div>
								</div>
							</div>
				<?php
						}
					}
				?>
            </div>
        </div>            
    </div>
    <!-- intro Area End -->
