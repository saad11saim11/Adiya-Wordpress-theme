<?php
$title		= $settings['title'] ? '<h2>'.$settings['title'].'</h2>' : '';
$num=rand();
?>
 <!-- potential Area Start-->
    <div class="potential-area pd-top-135 pd-bottom-115">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="section-title text-center">
                        <?php  echo $title;?>
                        <ul class="potential-nav nav nav-pills" id="pills-tab" role="tablist">
							<?php 
								$i=1;
								foreach ($settings['sections'] as $section){ 
							?>
                            <li class="nav-item" role="presentation">
                              <button class="nav-link <?php echo ($i == 1 ? 'active' : ''); ?>" id="pills-<?php echo $i.'-'.$num;?>-tab" data-bs-toggle="pill" data-bs-target="#pills-<?php echo $i.'-'.$num;?>" type="button" role="tab" aria-controls="pills-<?php echo $i.'-'.$num;?>" aria-selected="true"><?php echo $section['tab_title'];?></button>
                            </li>
							<?php $i++; }?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="tab-content" id="pills-tabContent">
						<?php 
							$i=1;
							foreach ($settings['sections'] as $section){ 
								$img = wp_get_attachment_image($section['image']['id'], 'full');
						?>
                        	<div class="tab-pane fade show <?php echo ($i == 1 ? 'active' : ''); ?>" id="pills-<?php echo $i.'-'.$num;?>" role="tabpanel" aria-labelledby="pills-<?php echo $i.'-'.$num;?>-tab">
                            <div class="row">
                                <div class="col-lg-6 align-self-center">
                                    <div class="potential-wrap">
                                        <h3><?php echo $section['title'];?></h3>
                                        <p class="mb-4"><?php echo $section['text'];?>.</p>
                                    </div>
                                </div>
                                <div class="col-lg-6 align-self-center">
                                    <div class="thumb">
                                        <?php echo $img;?>
                                    </div>
                                </div>
                            </div>
                        </div>
						<?php $i++; }?>
                    </div>
                </div>
            </div>
        </div>            
    </div>
    <!-- potential Area End -->
