<?php

namespace WebangonAddon\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
 
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly


class counters extends Widget_Base {

    public function get_name() {
        return 'counters';
    }

    public function get_title() {
        return __('Counters', 'foores');
    }
 
    public function get_icon() {
        return 'eicon-form-horizontal';
    }

    public function get_categories() {
        return ['foores-addons'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __('General', 'foores'),
            ]
        );
		
		
		$this->add_control(
            'title', [
                'type' => Controls_Manager::TEXTAREA,
                'label' =>   esc_html__('Title', 'foores'),
                'label_block' => true,
				'default' => 'Exceptional opportunities',
            ]
        );
		
		$this->add_control(
            'text', [
                'type' => Controls_Manager::TEXTAREA,
                'label' =>   esc_html__('Text', 'foores'),
                'label_block' => true,
				'default' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Eget aenean accumsan bibendum gravida maecenas augue elementum et neque. Suspendisse imperdiet .','foores'),
            ]
        );
		
		$repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'title', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Title', 'foores'),
                'label_block' => true,
				'default' => 'Students worldwide',
            ]
        );
		
		$repeater->add_control(
            'number', [
                'type' => Controls_Manager::NUMBER,
                'label' =>   esc_html__('Number', 'foores'),
                'label_block' => true,
				'default' => '35',
            ]
        );
		
		$repeater->add_control(
            'suffix', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Suffix', 'foores'),
                'label_block' => true,
				'default' => 'm',
            ]
        );
		
		$this->add_control(
            'sections',
            [
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
        );

        $this->end_controls_tab();
		
		


        $this->end_controls_section();
    }
        
    protected function render() {

        $settings = $this->get_settings();
        require dirname(__FILE__) .'/one.php';      
    }

}

$widgets_manager->register_widget_type(new \WebangonAddon\Widgets\counters());