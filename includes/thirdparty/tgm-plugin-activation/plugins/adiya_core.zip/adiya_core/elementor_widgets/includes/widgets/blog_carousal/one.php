<?php
$args = array( 'post_type' => 'post', 'orderby' => $settings['order_by'], 'order' => $settings['order'], 'posts_per_page' => $settings['number'] );
if( $settings['category'] ) 
	$args['tax_query'] = array(array('taxonomy' => 'category','field' => 'id','terms' => $settings['category'] )); 
$new_query = new WP_Query( $args );
?>
<!-- lesson Area Start-->
<section class="lesson-area">
	<div class="container">
		<div class="row">
			<?php if( $settings['title'] ): ?>
				<div class="col-lg-12">
					<div class="section-title">
						<h2><?php echo $settings['title']; ?></h2>
					</div>
				</div>
			<?php endif; ?>
			
			<?php if( $new_query -> have_posts() && $settings['number'] > 0 ): ?>
			<div class="col-lg-12">
				<div class="lesson-slider owl-carousel">
					<?php
						while( $new_query -> have_posts() ): 
								$new_query -> the_post();
					?>
					<div class="item">
						<div class="single-blog-wrap style-2">
							<div class="thumb">
								<?php the_post_thumbnail('foores-690x345'); ?>
							</div>
							<div class="wrap-details">
								<h5><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
								<p><?php echo substr(strip_tags(get_the_content()) , 0 , 100); ?></p>
							</div>
						</div>
					</div>
					<?php endwhile ; ?>
				</div>
			</div>
			<?php
				endif;
				wp_reset_postdata();
			?>
		</div>
	</div>
</section>
<!-- lesson Area End -->