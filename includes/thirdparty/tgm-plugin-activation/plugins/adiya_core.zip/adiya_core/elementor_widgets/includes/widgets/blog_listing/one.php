<?php
$args = array( 'post_type' => 'post', 'orderby' => $settings['order_by'], 'order' => $settings['order'], 'posts_per_page' => $settings['number'] );
if( $settings['category'] ) 
	$args['tax_query'] = array(array('taxonomy' => 'category','field' => 'id','terms' => $settings['category'] )); 
$new_query = new WP_Query( $args );
?>
<!-- blog Area Start-->
<section>
	<div class="container">
		<?php if( $settings['title'] || $settings['btn_txt'] ): ?>
		<div class="row">
			<div class="col-md-8">
				<?php if( $settings['title'] ): ?>
					<div class="section-title">
						<h2><?php echo $settings['title']; ?></h2>
					</div>
				<?php endif; ?>
			</div>
			<div class="col-md-4 text-md-end d-md-block d-none">
				<?php if( $settings['btn_txt'] ): ?>
				<a class="btn btn-base-light" href="<?php echo $settings['btn_lnk'] ? $settings['btn_lnk'] : '#' ?>"><?php echo $settings['btn_txt']; ?></a>
				<?php endif; ?>
			</div>
		</div>
		<?php endif; ?>
		<?php if( $new_query -> have_posts() && $settings['number'] > 0 ): ?>
		<div class="row">
			<?php
				while( $new_query -> have_posts() ): 
						$new_query -> the_post();
			?>
			<div class="col-xl-3 col-lg-4 col-md-6">
				<div class="single-course-wrap">
					<div class="thumb">
						<?php the_post_thumbnail('foores-329x190'); ?>
					</div>
					<div class="wrap-details">
						<h6><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h6>
						<p><?php echo substr(strip_tags(get_the_content()) , 0 , 88); ?></p>
						<div class="price-wrap">
							<div class="row align-items-center">
								<div class="col-6">
									<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>">By <?php the_author(); ?></a>
								</div>
								<div class="col-6 text-end">
									<div class="date"><?php the_time('d M, Y'); ?></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php endwhile ; ?>
		</div>
		<?php
			endif;
			wp_reset_postdata();
		?>
	</div>
</section>
<!-- blog Area End -->