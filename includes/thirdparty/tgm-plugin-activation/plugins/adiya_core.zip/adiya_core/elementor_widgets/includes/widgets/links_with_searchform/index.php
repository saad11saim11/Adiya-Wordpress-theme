<?php

namespace WebangonAddon\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
 
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly


class links_with_searchform extends Widget_Base {

    public function get_name() {
        return 'links_with_searchform';
    }

    public function get_title() {
        return __('Links with Search Form', 'foores');
    }
 
    public function get_icon() {
        return 'eicon-accordion';
    }

    public function get_categories() {
        return ['foores-addons'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __('General', 'foores'),
            ]
        );
		
		$this->add_control(
            'heading', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Heading', 'foores'),
                'label_block' => true,
            ]
        );
		
		$repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'title', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Title', 'foores'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'link', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Link', 'foores'),
                'label_block' => true,
            ]
        );

		$this->add_control(
            'links',
            [
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ title }}}',                
            ]
        );
		
		$this->add_control(
			'show_form',
			[
				'type' => Controls_Manager::SWITCHER,
				'label' => esc_html__( 'Show Search Form', 'plugin-domain' ),
				'label_on' => esc_html__( 'Show', 'your-plugin' ),
				'label_off' => esc_html__( 'Hide', 'your-plugin' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'course_check',
			[
				'type' => Controls_Manager::SWITCHER,
				'label' => esc_html__( 'Course Search', 'plugin-domain' ),
				'label_on' => esc_html__( 'Yes', 'your-plugin' ),
				'label_off' => esc_html__( 'No', 'your-plugin' ),
			]
		);

        $this->end_controls_tab();

        $this->end_controls_section();
    }
        
    protected function render() {

        $settings = $this->get_settings();
        require dirname(__FILE__) .'/one.php';      
    }

}

$widgets_manager->register_widget_type(new \WebangonAddon\Widgets\links_with_searchform());