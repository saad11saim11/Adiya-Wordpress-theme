<?php
$title		= $settings['title'] ? '<h2>'.$settings['title'].'</h2>' : '';
$text		= $settings['text'] ? '<p>'.$settings['text'].'</p>' : '';
?>
<!-- fact Area Start-->
<div class="text-center pd-top-135 pd-bottom-115 bg-clr">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-8">
				<div class="section-title">
					 <?php  echo $title.$text;?>
				</div>
			</div>
		</div>
		<div class="row justify-content-center">
			<?php 
				foreach ($settings['sections'] as $section){ 
			?>
				<div class="col-lg-3 col-sm-6">
				<div class="single-fact-wrap">
					<div class="fact-count">
						<h3><span class="counter"><?php echo $section['number'];?></span><?php echo $section['suffix'];?></h3>
					</div>
					<div class="wrap-details">
						<p><?php echo $section['title'];?></p>
					</div>
				</div>
			</div>
			<?php }?>
		</div>
	</div>            
</div>
<!-- fact Area End -->