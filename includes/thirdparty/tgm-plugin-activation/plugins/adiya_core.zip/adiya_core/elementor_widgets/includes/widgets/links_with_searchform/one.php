<div class="blog-cat">
	<div class="category-navbar navbar-area mt-0 border-top-0">
		<nav class="navbar navbar-expand-lg">
			<div class="container nav-container">
				<div class="responsive-mobile-menu">
					<button class="menu toggle-btn d-block d-lg-none" data-target="#themefie_main_menu" 
					aria-expanded="false" aria-label="Toggle navigation">
						<span class="icon-left"></span>
						<span class="icon-right"></span>
					</button>
				</div>
				<div class="nav-right-part nav-right-part-mobile">
					<ul>
						<li><a class="search header-search" href="#"><i class="fa fa-search"></i></a></li>
					</ul>
				</div>
				<div class="collapse navbar-collapse pad-10" id="themefie_main_menu">
					<ul class="navbar-nav menu-open">
						
						<?php if( $settings['heading'] ): ?>
						<li>
							<h5 class="mb-0"><?php echo $settings['heading']; ?></h5>
						</li>
						<?php endif; ?>
						
						<?php
							if( !empty($settings['links']) ){
								foreach ($settings['links'] as $link){
									if( $link['title'] ){
						?>
										<li>
											<a href="<?php echo $link['link'] ? $link['link'] : '#'; ?>"><?php echo $link['title']; ?></a>
										</li>
						<?php
									}
								}
							}
						?>
					</ul>
					<?php if( $settings['show_form'] ){ ?>
					
						<form action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
							<div class="single-input-wrap bg-transparent">
								<input type="text" name="s" id="search" value="<?php the_search_query(); ?>" placeholder="<?php echo esc_attr( $settings['course_check'] ? 'Search your best courses' : 'Search...' ); ?>" required />
								<?php if( $settings['course_check'] ){ ?>
								<input type="hidden" name="post_type" value="courses" />
								<?php } ?>
								<button type="submit"><i class="fa fa-search"></i></button>
							</div>
						</form>
                    
					<?php } ?>
				</div>
			</div>
		</nav>
	</div>
</div>