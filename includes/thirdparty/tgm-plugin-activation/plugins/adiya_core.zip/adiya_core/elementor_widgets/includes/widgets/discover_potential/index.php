<?php

namespace WebangonAddon\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
 
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly


class discover_potential extends Widget_Base {

    public function get_name() {
        return 'discover_potential';
    }

    public function get_title() {
        return __('Discover Potential', 'foores');
    }
 
    public function get_icon() {
        return 'eicon-form-horizontal';
    }

    public function get_categories() {
        return ['foores-addons'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __('General', 'foores'),
            ]
        );
		
		
		$this->add_control(
            'title', [
                'type' => Controls_Manager::TEXTAREA,
                'label' =>   esc_html__('Title', 'foores'),
                'label_block' => true,
				'default' => 'Discover your potential',
            ]
        );
		
		$this->add_control(
            'text', [
                'type' => Controls_Manager::TEXTAREA,
                'label' =>   esc_html__('Text', 'foores'),
                'label_block' => true,
				'default' => esc_html__('It offers us a new way to explore subjects us tomfoolery on the cheesed off I dropped a clanger to do with me bits enthusiastic about exploring subjects us tomfoolery trusted our partners.','foores'),
            ]
        );

		$this->add_control(
            'b1_txt', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Button 1 Text', 'foores'),
                'label_block' => true,
				'default' => esc_html__('Get Started','foores'),
            ]
        );
		$this->add_control(
            'b1_lnk', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Button 1 Link', 'foores'),
                'label_block' => true,
            ]
        );
		
		$this->add_control(
            'b2_txt', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Button 2 Text', 'foores'),
                'label_block' => true,
				'default' => esc_html__('Resignation','foores'),
            ]
        );
		$this->add_control(
            'b2_lnk', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Button 2 Link', 'foores'),
                'label_block' => true,
            ]
        );
		
		$this->add_control(
            'bgimg', [
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,               
                'label' =>   esc_html__('Side Image', 'foores'),
            ]
        ); 
		
		$repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'point', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Enter Points', 'foores'),
                'label_block' => true,
            ]
        );
		
		$this->add_control(
            'points',
            [
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
        );

        $this->end_controls_tab();
		
		


        $this->end_controls_section();
    }
        
    protected function render() {

        $settings = $this->get_settings();
        require dirname(__FILE__) .'/one.php';      
    }

}

$widgets_manager->register_widget_type(new \WebangonAddon\Widgets\discover_potential());