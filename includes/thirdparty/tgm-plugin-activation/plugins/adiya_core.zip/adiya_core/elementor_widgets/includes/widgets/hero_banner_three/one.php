<?php
$heading	= $settings['heading'] ? '<h5>'.$settings['heading'].'</h5>' : '';
$title		= $settings['title'] ? '<p>'.$settings['title'].'<p>' : '';

$rheading	= $settings['title_right'] ? '<h2>'.$settings['title_right'].'</h2>' : '';
$rtitle		= $settings['text_right'] ? '<div class="banner-content"><p>'.$settings['text_right'].'<p></div>' : '';

$img 		= $settings['thumb']['url'];
?>
<!-- Banner Area Start-->
<section class="banner-area style-2">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-4">
				<div class="banner-user-area text-center h-100">
					<div class="user-inner">
						<?php echo $heading.$title; ?>
						<a class="btn btn-base" href="<?php echo $settings['b_lnk'];?>"><?php echo $settings['b_txt'];?></a>
					</div>
				</div>
			</div>
			<div class="col-lg-8">
				<div class="banner-style-2" style="background-image: url(<?php echo $img; ?>);">
					<div class="row">
						<div class="col-md-8 align-self-center">
							<div class="banner-inner-2 text-md-start text-center">
								<?php echo $rheading.$rtitle; ?>
							</div>
						</div>
					</div>
				</div>
			</div>                
		</div>
	</div>
</section>
<!-- Banner Area End -->