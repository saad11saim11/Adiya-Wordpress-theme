<?php

namespace WebangonAddon\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
 
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly


class home_clients extends Widget_Base {

    public function get_name() {
        return 'home_clients';
    }

    public function get_title() {
        return __('Clients', 'foores');
    }
 
    public function get_icon() {
        return 'eicon-form-vertical';
    }

    public function get_categories() {
        return ['foores-addons'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __('General', 'foores'),
            ]
        );
				
		$repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'image', [
                'type' => Controls_Manager::MEDIA,
                'label' =>   esc_html__('Image', 'foores'),
                'label_block' => true,
            ]
        );
		
		$this->add_control(
            'clients',
            [
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_section();
    }
        
    protected function render() {

        $settings = $this->get_settings();
        require dirname(__FILE__) .'/one.php';      
    }

}

$widgets_manager->register_widget_type(new \WebangonAddon\Widgets\home_clients());