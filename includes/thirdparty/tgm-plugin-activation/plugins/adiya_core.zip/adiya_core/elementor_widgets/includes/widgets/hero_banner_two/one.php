<?php
	$title		= $settings['title'] ? '<h1>'.$settings['title'].'</h1>' : '';
	$text		= $settings['text'] ? '<div class="banner-content"><p>'.$settings['text'].'</p></div>' : '';
	$B_txt		= $settings['B_txt'];
	$B_lnk		=$settings['B_lnk'];
	$img 		= $settings['bgimg']['url'];
?>
<!-- Banner Area Start-->
<section class="banner-area style-3" style="background-image: url(<?php echo $img; ?>);">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-xl-7 col-lg-8 align-self-center">
				<div class="banner-inner text-center">
					<?php  echo $title.$text;?>
					<a class="btn btn-base" href="<?php echo $B_lnk; ?>"><?php echo $B_txt;?></a>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Banner Area End -->