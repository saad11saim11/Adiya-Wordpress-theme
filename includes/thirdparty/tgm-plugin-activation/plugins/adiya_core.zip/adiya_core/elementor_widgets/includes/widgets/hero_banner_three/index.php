<?php

namespace WebangonAddon\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
 
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly


class hero_banner_three extends Widget_Base {

    public function get_name() {
        return 'hero_banner_three';
    }

    public function get_title() {
        return __('Hero Banner Three', 'foores');
    }
 
    public function get_icon() {
        return 'eicon-form-horizontal';
    }

    public function get_categories() {
        return ['foores-addons'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __('General', 'foores'),
            ]
        );

        $this->start_controls_tabs('tctb');

        $this->start_controls_tab(
            'hb1',
            [
                'label' => esc_html__( 'Left', 'foores' ),               
            ]
        );
		
		$this->add_control(
            'heading', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Heading', 'foores'),
                'label_block' => true,
				'default' => 'Hi Hugo Fabry,',
            ]
        );
		$this->add_control(
            'title', [
                'type' => Controls_Manager::TEXTAREA,
                'label' =>   esc_html__('Title', 'foores'),
                'label_block' => true,
				'default' => 'Welcome to Foores,Keep learning in the moments that matter.',
            ]
        );
		
		$this->add_control(
            'b_txt', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Button Text', 'foores'),
                'label_block' => true,
				'default' => 'Start my free month',
            ]
        );
		
		$this->add_control(
            'b_lnk', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Button Link', 'foores'),
                'label_block' => true,
            ]
        );
		
		$this->end_controls_tab();

        $this->start_controls_tab(
            'hb2',
            [
                'label' => esc_html__( 'Right', 'foores' ),                
            ]
        );
		
		$this->add_control(
            'thumb', [
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,               
                'label' =>   esc_html__('Image', 'foores'),
            ]
        ); 

        $this->add_control(
            'title_right', [
                'type' => Controls_Manager::TEXT,
                'label' =>   esc_html__('Title', 'foores'),
                'label_block' => true,
				'default' => 'Find the Best Courses & Upgrade Your Skills.',
            ]
        );
		
		$this->add_control(
            'text_right', [
                'type' => Controls_Manager::TEXTAREA,
                'label' =>   esc_html__('Text', 'foores'),
                'label_block' => true,
				'default' => 'Increase your skills by using special features and professional courses from Foores.',
            ]
        );

		$this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
    }
        
    protected function render() {

        $settings = $this->get_settings();
        require dirname(__FILE__) .'/one.php';      
    }

}

$widgets_manager->register_widget_type(new \WebangonAddon\Widgets\hero_banner_three());