<?php

namespace WebangonAddon\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
 
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly


class faqs extends Widget_Base {

    public function get_name() {
        return 'faqs';
    }

    public function get_title() {
        return __('FAQ\'s', 'foores');
    }
 
    public function get_icon() {
        return 'eicon-accordion';
    }

    public function get_categories() {
        return ['foores-addons'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __('General', 'foores'),
            ]
        );
		
		$repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'question', [
                'type' => Controls_Manager::TEXTAREA,
                'label' =>   esc_html__('Question', 'foores'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'answer', [
                'type' => Controls_Manager::TEXTAREA,
                'label' =>   esc_html__('Answer', 'foores'),
                'label_block' => true,
            ]
        );

		
		$this->add_control(
            'faqs',
            [
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ question }}}',                
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_section();
    }
        
    protected function render() {

        $settings = $this->get_settings();
        require dirname(__FILE__) .'/one.php';      
    }

}

$widgets_manager->register_widget_type(new \WebangonAddon\Widgets\faqs());